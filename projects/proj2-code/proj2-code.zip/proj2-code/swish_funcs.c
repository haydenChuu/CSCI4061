#define _GNU_SOURCE

#include "swish_funcs.h"

#include <assert.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include "job_list.h"
#include "string_vector.h"

#define MAX_ARGS 10

int tokenize(char *s, strvec_t *tokens) {
    // TODO Task 0: Tokenize string s
    // Assume each token is separated by a single space (" ")
    // Use the strtok() function to accomplish this
    // Add each token to the 'tokens' parameter (a string vector)
    // Return 0 on success, -1 on error
    if (tokens == NULL) {
        printf("No string vector");
        return -1;
    }

    char *token = strtok(s, " ");
    if (token == NULL) {
        printf("Empty string");
    }

    while (token != NULL) {
        if (strvec_add(tokens, token) != 0) {
            printf("Failed to add token to string vector");
            return -1;
        }
        token = strtok(NULL, " ");
    }
    return 0;
}

int run_command(strvec_t *tokens) {
    // TODO Task 2: Execute the specified program (token 0) with the
    // specified command-line arguments
    // THIS FUNCTION SHOULD BE CALLED FROM A CHILD OF THE MAIN SHELL PROCESS
    // Hint: Build a string array from the 'tokens' vector and pass this into execvp()
    // Another Hint: You have a guarantee of the longest possible needed array, so you
    // won't have to use malloc.

    // TODO Task 3: Extend this function to perform output redirection before exec()'ing
    // Check for '<' (redirect input), '>' (redirect output), '>>' (redirect and append output)
    // entries inside of 'tokens' (the strvec_find() function will do this for you)
    // Open the necessary file for reading (<), writing (>), or appending (>>)
    // Use dup2() to redirect stdin (<), stdout (> or >>)
    // DO NOT pass redirection operators and file names to exec()'d program
    // E.g., "ls -l > out.txt" should be exec()'d with strings "ls", "-l", NULL

    // TODO Task 4: You need to do two items of setup before exec()'ing
    // 1. Restore the signal handlers for SIGTTOU and SIGTTIN to their defaults.
    // The code in main() within swish.c sets these handlers to the SIG_IGN value.
    // Adapt this code to use sigaction() to set the handlers to the SIG_DFL value.
    // 2. Change the process group of this process (a child of the main shell).
    // Call getpid() to get its process ID then call setpgid() and use this process
    // ID as the value for the new process group ID

    if (tokens == NULL || tokens->length == 0) {
        return -1;
    }

    int input_op_index = strvec_find(tokens, "<");
    int output_op_index = strvec_find(tokens, ">");
    int append_op_index = strvec_find(tokens, ">>");

    int stop_index = tokens->length;
    if (input_op_index != -1 && input_op_index < stop_index) {
        stop_index = input_op_index;
    }
    if (output_op_index != -1 && output_op_index < stop_index) {
        stop_index = output_op_index;
    }
    if (append_op_index != -1 && append_op_index < stop_index) {
        stop_index = append_op_index;
    }

    char *args[MAX_ARGS];
    int args_counter = stop_index;

    if (args_counter >= MAX_ARGS) {
        args_counter = MAX_ARGS - 1;
    }

    int i = 0;
    while (i < args_counter) {
        args[i] = strvec_get(tokens, i);
        i++;
    }
    args[args_counter] = NULL;

    if (input_op_index != -1) {
        char *infile = strvec_get(tokens, input_op_index + 1);
        int input_fd = open(infile, O_RDONLY);
        if (input_fd < 0) {
            perror("Failed to open input file");
            return -1;
        }
        if (dup2(input_fd, STDIN_FILENO) == -1) {
            perror("Failed to open input file");
            close(input_fd);
            return -1;
        }
        close(input_fd);
    }

    if (output_op_index != -1) {
        char *outfile = strvec_get(tokens, output_op_index + 1);
        int output_fd = open(outfile, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
        if (output_fd < 0) {
            perror("Failed to open output file");
            return -1;
        }
        if (dup2(output_fd, STDOUT_FILENO) == -1) {
            perror("Failed to open output file");
            close(output_fd);
            return -1;
        }
        close(output_fd);
    } else if (append_op_index != -1) {
        char *outfile = strvec_get(tokens, append_op_index + 1);
        int output_fd = open(outfile, O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR);
        if (output_fd < 0) {
            perror("Failed to open output file");
            return -1;
        }
        if (dup2(output_fd, STDOUT_FILENO) == -1) {
            perror("Failed to open output file");
            close(output_fd);
            return -1;
        }
        close(output_fd);
    }

    struct sigaction sac;
    sac.sa_handler = SIG_DFL;
    if (sigemptyset(&sac.sa_mask) == -1) {
        perror("sigemptyset");
        return -1;
    }
    sac.sa_flags = 0;
    if (sigaction(SIGTTIN, &sac, NULL) == -1 || sigaction(SIGTTOU, &sac, NULL) == -1) {
        perror("sigaction");
        return -1;
    }

    pid_t current_pid = getpid();
    if (setpgid(current_pid, current_pid) == -1) {
        perror("setpgid");
        return -1;
    }

    if (execvp(args[0], args) == -1) {
        perror("exec");
        return -1;
    }

    return 0;
}

int resume_job(strvec_t *tokens, job_list_t *jobs, int is_foreground) {
    // TODO Task 5: Implement the ability to resume stopped jobs in the foreground
    // 1. Look up the relevant job information (in a job_t) from the jobs list
    //    using the index supplied by the user (in tokens index 1)
    //    Feel free to use sscanf() or atoi() to convert this string to an int
    // 2. Call tcsetpgrp(STDIN_FILENO, <job_pid>) where job_pid is the job's process ID
    // 3. Send the process the SIGCONT signal with the kill() system call
    // 4. Use the same waitpid() logic as in main -- don't forget WUNTRACED
    // 5. If the job has terminated (not stopped), remove it from the 'jobs' list
    // 6. Call tcsetpgrp(STDIN_FILENO, <shell_pid>). shell_pid is the *current*
    //    process's pid, since we call this function from the main shell process

    // TODO Task 6: Implement the ability to resume stopped jobs in the background.
    // This really just means omitting some of the steps used to resume a job in the foreground:
    // 1. DO NOT call tcsetpgrp() to manipulate foreground/background terminal process group
    // 2. DO NOT call waitpid() to wait on the job
    // 3. Make sure to modify the 'status' field of the relevant job list entry to BACKGROUND
    //    (as it was STOPPED before this)

    if (tokens == NULL || tokens->length != 2) {
        printf("Failed due to empty tokens or incorrect format");
        return -1;
    }

    int job_index;
    char *second_token = strvec_get(tokens, 1);
    if (second_token == NULL) {
        printf("Failed to strvec_get\n");
        return -1;
    }
    if (sscanf(second_token, "%d", &job_index) != 1) {
        printf("Failed to sscanf\n");
        return -1;
    }

    job_t *current_process = job_list_get(jobs, job_index);
    if (current_process == NULL) {
        fprintf(stderr, "Job index out of bounds\n");
        return -1;
    }

    if (current_process->status != STOPPED) {
        printf("Failed due to attempt to resume not stopped process\n");
        return -1;
    }

    pid_t stopped_pid = current_process->pid;
    if (is_foreground == 1) {
        if (tcsetpgrp(STDIN_FILENO, stopped_pid) == -1) {
            perror("Failed to tcsetpgrp current process");
            return -1;
        }

        if (kill(-stopped_pid, SIGCONT) == -1) {
            perror("Failed to kill");
            return -1;
        }

        int status;
        if (waitpid(stopped_pid, &status, WUNTRACED) == -1) {
            perror("Failed to waitpid for child");
            return -1;
        }

        if (!(WIFSTOPPED(status))) {
            if (job_list_remove(jobs, job_index) == -1) {
                printf("Failed to job_list_remove\n");
                return -1;
            }
        }

        // check later cause i moved processes
        pid_t current_pid = getpid();
        if (tcsetpgrp(STDIN_FILENO, current_pid) == -1) {
            perror("Failed to tcsetpgrp current process");
            return -1;
        }
        return 1;
    } else {
        if (kill(-stopped_pid, SIGCONT) == -1) {
            perror("Failed to kill");
            return -1;
        }
        current_process->status = BACKGROUND;
    }
    return 0;
}

int await_background_job(strvec_t *tokens, job_list_t *jobs) {
    // TODO Task 6: Wait for a specific job to stop or terminate
    // 1. Look up the relevant job information (in a job_t) from the jobs list
    //    using the index supplied by the user (in tokens index 1)
    // 2. Make sure the job's status is BACKGROUND (no sense waiting for a stopped job)
    // 3. Use waitpid() to wait for the job to terminate, as you have in resume_job() and main().
    // 4. If the process terminates (is not stopped by a signal) remove it from the jobs list

    if (tokens == NULL || tokens->length != 2) {
        printf("Failed due to empty tokens or incorrect format\n");
        return -1;
    }

    int job_index;
    char *second_token = strvec_get(tokens, 1);
    if (second_token == NULL) {
        printf("Failed to strvec_get\n");
        return -1;
    }

    if (sscanf(second_token, "%d", &job_index) != 1) {
        printf("Failed to sscanf\n");
        return -1;
    }

    job_t *current_process = job_list_get(jobs, job_index);
    if (current_process == NULL) {
        fprintf(stderr, "Job index out of bounds\n");
        return -1;
    }

    if (current_process->status != BACKGROUND) {
        fprintf(stderr, "Job index is for stopped process not background process\n");
        return -1;
    }

    pid_t background_pid = current_process->pid;
    int status;
    if (waitpid(background_pid, &status, WUNTRACED) == -1) {
        perror("Failed to waitpid for child");
        return -1;
    }

    if (WIFSTOPPED(status)) {
        current_process->status = STOPPED;
    } else {
        job_list_remove(jobs, job_index);
    }
    return 0;
}

int await_all_background_jobs(job_list_t *jobs) {
    // TODO Task 6: Wait for all background jobs to stop or terminate
    // 1. Iterate through the jobs list, ignoring any stopped jobs
    // 2. For a background job, call waitpid() with WUNTRACED.
    // 3. If the job has stopped (check with WIFSTOPPED), change its
    //    status to STOPPED. If the job has terminated, do nothing until the
    //    next step (don't attempt to remove it while iterating through the list).
    // 4. Remove all background jobs (which have all just terminated) from jobs list.
    //    Use the job_list_remove_by_status() function.
    for (int job_index = 0; job_index < jobs->length; job_index++) {
        job_t *current_process = job_list_get(jobs, job_index);
        if (current_process == NULL) {
            printf("Failed to job_list_get\n");
            return -1;
        }

        if (current_process->status != BACKGROUND) {
            continue;
        }

        pid_t background_pid = current_process->pid;
        int status;
        if (waitpid(background_pid, &status, WUNTRACED) == -1) {
            perror("Failed to waitpid for child");
            return -1;
        }

        if (WIFSTOPPED(status)) {
            current_process->status = STOPPED;
        }
    }
    job_list_remove_by_status(jobs, BACKGROUND);
    return 0;
}
